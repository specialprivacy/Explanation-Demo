* * ESECUZIONE * *
Linux: java -jar Special-1.0.jar
Windows: doppio click

* * UTILIZZO * *
Click su Ontology > Load from File; selezionare Ontologies/Ontology_Special.owl .
Click sul tab Usage Policies.
Qui è possibile fare due scelte:
1) Selezionare due politiche e cliccare su Compare selected Policies per confrontarle;
2) Cliccare su Create new Policy per creare una nuova politica.

NB: Dei confronti effettuati verranno salvati e riportati solo quelli significativi.
Ad esempio se i confronti effettuati sono (A,B), (A,C), (A,D) e tra questi A e D sono incompatibili mentre le altre due sono compatibili, il report finale NON conterrà la coppia (A,D).