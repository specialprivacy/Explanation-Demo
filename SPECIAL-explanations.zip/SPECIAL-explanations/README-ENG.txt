* * HOW TO EXECUTE * *
Linux (command line): java -jar Special-1.0.jar
Windows: double click on .jar file

* * USAGE * *
Click Ontology > Load from File; select Ontologies/Ontology_Special.owl .
Click tab Usage Policies.
Here two options are available:
1) Select two policies and click the "Compare selected Policies" button to generate an explanation;
2) Click "Create new Policy" to add more policies to the sample repository.

Note: only the relevant parts of the comparison are reported, in order to help users focus on the important features of the policies.
